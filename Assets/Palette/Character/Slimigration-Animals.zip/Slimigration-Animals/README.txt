Thanks for downloading the assets!
Feel free to contact me if you have something to say
(whether critic, advices,etc). 
I'll try to respond asap!

This assets is free to use for commercial and personal use.

I'm not consent for redistributing this asset and said it as your own. 
(This is including for NFT-like product as well).

Hope this help your game-dev endeavor.


@pillowbyte
https://twitter.com/pillowbyte
pillowbyte.itch.io